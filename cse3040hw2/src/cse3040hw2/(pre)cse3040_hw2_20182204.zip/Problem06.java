package cse3040hw2;

interface IntSequence{
	boolean hasNext();
	int next();
}

class FibonacciSequence implements IntSequence{
	private int n;
	private int pn;
	private int ppn;
	public FibonacciSequence() {
		n=-1;
		pn=1;
		ppn=0;
	}
	public boolean hasNext() {
		return (n++)!=20;
	}
	public int next() {
		if(n==0) return 0;
		if(n==1) return 1;
		int ans = pn+ppn;
		ppn=pn;
		pn=ans;
		return ans;
	}
}

public class Problem06 {
	public static void main(String[] args) {
		IntSequence seq = new FibonacciSequence();
		for (int i = 0; i < 20; i++) {
			if (seq.hasNext() == false)
				break;
			System.out.print(seq.next() + " ");
		}
		System.out.println(" ");
	}
}